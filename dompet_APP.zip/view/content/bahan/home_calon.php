<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"> </h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
	
                        <ol class="breadcrumb pull-right">
						
                            <li><a href="tel:0778676763"><i class="glyphicon glyphicon-eye-open"></i> Call Center</a></li>
                            
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!--row -->
				User Anda Belum di konfirmasi admin harap hubungi call center atau tunggu..!
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="white-box">
                            <div class="r-icon-stats"> <i class="glyphicon glyphicon-user bg-megna"></i>
                                <div class="bodystate">
                                    <h4>Pengajuan</h4> <span class="text-muted"> Pemasangan </span> </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-sm-6">
                        <div class="white-box">
                            <div class="r-icon-stats"> <i class="glyphicon glyphicon-book bg-success"></i>
                                <div class="bodystate">
                                    <h4>Layanan</h4> <span class="text-muted">Pengaduan</span> </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!--/row -->
                