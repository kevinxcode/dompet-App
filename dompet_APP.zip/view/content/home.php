<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"> </h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
	
                        <ol class="breadcrumb pull-right">
						
                            <li><a href="tel:081541277051"><i class="glyphicon glyphicon-user"></i> Account <b> <?php echo $_SESSION['nama'];?></b></a></li>
                            
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!--row -->
                <div class="row">
                    <div class="col-md-3 col-sm-6">
					<a href="index.php?p=credit">
                        <div class="white-box">
                            <div class="r-icon-stats"> <i class="glyphicon glyphicon-bitcoin"></i>
                                <div class="bodystate">
                                    <h4>Credit</h4> <span class="text-muted"> Pengeluaran </span> </div>
                            </div>
                        </div>
						</a>
                    </div>
					
				
                    
                    <div class="col-md-3 col-sm-6">
                        <div class="white-box">
                            <div class="r-icon-stats"> <i class="glyphicon glyphicon-book bg-success"></i>
                                <div class="bodystate">
                                    <h4>Layanan</h4> <span class="text-muted">Pengaduan</span> </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <!--/row -->
                